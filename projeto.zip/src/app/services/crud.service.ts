import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class ServiceNameService {
  constructor(private httpClient: HttpClient) { }
}
@Injectable({
  providedIn: 'root'
})
export class CrudService {

  constructor(private http: HttpClient) { }
  public getSeries(): Observable<any>{
return this.http.get('http://gateway.marvel.com/v1/public/series?ts=1601747906&apikey=85cc7b66c4df5934785cb702a339f86d&hash=01894c21d6249909b014cf65d185b294');
}
}

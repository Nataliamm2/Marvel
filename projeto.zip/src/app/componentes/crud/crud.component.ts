import { Imagens } from './../../model/placeholder.model';
import { CrudService } from 'src/app/services/crud.service';
import { Component, OnInit } from '@angular/core';
import { error } from 'protractor';
import { Console } from 'console';

@Component({
  selector: 'app-crud',
  templateUrl: './crud.component.html',
  styleUrls: ['./crud.component.css']
})
export class CrudComponent implements OnInit {
 imagens: any;
 Erro: any;
  constructor(private crudService: CrudService) {
    this.getter(); }

  ngOnInit(): void {
  }
 getter(){
   this.crudService.getSeries().subscribe((data: Imagens) => {
       this.imagens = data;
       console.log('A variavel que preenchemos', this.imagens);
       console.log('O data que recebemos', data);
      },
    (error: any ) => {
      this.Erro = error;
      console.error('Error:', error);
   }
   );
 }
}

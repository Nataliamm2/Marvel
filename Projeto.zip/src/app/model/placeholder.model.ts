
export class Imagens {

          id: number;
          title: string;
          description: string;
          resourceURI: string;
          urls: string;
              type: string;
              url: string;

            }


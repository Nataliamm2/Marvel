import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Injectable({providedIn: 'root'})
export class ServiceNameService {
  constructor(private httpClient: HttpClient) { }
}
@Injectable({
  providedIn: 'root'
})
export class CrudService {


  constructor(private http: HttpClient) { }

  public getAllSeries(): Observable<any>{
return this.http.get('http://gateway.marvel.com/v1/public/series?ts=1602177466&apikey=497f42c45998159ca35c19003acae2f1&hash=8fc7caae25df44cc2abffa4e44e137b4');
}

}






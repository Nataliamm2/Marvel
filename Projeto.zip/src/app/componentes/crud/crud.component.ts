import { Imagens } from './../../model/placeholder.model';
import { CrudService } from 'src/app/services/crud.service';
import { Component, OnInit } from '@angular/core';
import { error } from 'protractor';
import { Console } from 'console';
import {MatToolbarModule} from '@angular/material/toolbar';

@Component({
  selector: 'app-crud',
  templateUrl: './crud.component.html',
  styleUrls: ['./crud.component.css']
})
export class CrudComponent implements OnInit {
 series: any;
 Erro: any;
  constructor(private crudService: CrudService) {
    this.getAllSeries(); }


  ngOnInit(): void {
  }
 // tslint:disable-next-line: typedef
 getAllSeries(){
   this.crudService.getAllSeries().subscribe((data: Imagens) => {
       this.series = data;
       console.log('A variavel ', this.series);
       console.log('retorno', data);
      },
    // tslint:disable-next-line: no-shadowed-variable
    (error: any ) => {
      this.Erro = error;
      console.error('Error:', error);
   }
   );
 }
}
